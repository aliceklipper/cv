webpackJsonp([2],{482:function(a,b,c){"use strict";Object.defineProperty(b,"__esModule",{value:!0});var d=c(13),e=c.n(d),f=c(483),g=c.n(f),h=c(484),i=c.n(h),j=c(485),k=c.n(j),l=c(486),m=c.n(l),n=c(487),o=c.n(n);/**
 * @file Alice Klipper's CV, Font Awesome 5, brands.
 * @author Alice Klipper <aliceklipper@yandex.com> (https://t.me/aliceklipper)
 * @license MIT
 * @copyright Alice Klipper, 2017
 * 
 */b["default"]=Object(d.css)([["@font-face{font-family:'Font Awesome 5 Brands';font-style:normal;font-weight:900;src:url('",g.a,"');src:url('",g.a,"?#iefix') format('embedded-opentype'), url('",i.a,"') format('woff2'), url('",k.a,"') format('woff'), url('",m.a,"') format('truetype'), url('",o.a,"#fontawesome') format('svg');}"],[" .fab{font-family:'Font Awesome 5 Brands',sans-serif;font-weight:900;}"]])},483:function(a,b,c){a.exports=c.p+"32f0d0b2d094abd01fc50a158e25e049.eot"},484:function(a,b,c){a.exports=c.p+"c1129190b0131ed5aa8dba8557f12571.woff2"},485:function(a,b,c){a.exports=c.p+"a4957342d57a17ec474f6ca4299b3ddb.woff"},486:function(a,b,c){a.exports=c.p+"fa43d6f38bfdd2abff3ee837cb37517f.ttf"},487:function(a,b,c){a.exports=c.p+"ea2b8e77ae6d4a65694b59ea2bfc6ec5.svg"}});